package edu.umn.ncs

// Person -> Phone relation
class PersonPhone extends PersonContact implements Serializable {
	PhoneNumber	phoneNumber
	PhoneType	phoneType
}

