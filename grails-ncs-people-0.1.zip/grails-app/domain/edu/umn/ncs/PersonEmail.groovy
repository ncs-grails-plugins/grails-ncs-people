package edu.umn.ncs

class PersonEmail extends PersonContact implements Serializable {
	EmailAddress    emailAddress
	EmailType       emailType
}

